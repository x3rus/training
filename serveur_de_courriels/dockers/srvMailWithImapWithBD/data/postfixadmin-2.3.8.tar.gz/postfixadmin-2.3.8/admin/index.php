<?php
header ("Location: ../login.php");
exit(0);
?>
